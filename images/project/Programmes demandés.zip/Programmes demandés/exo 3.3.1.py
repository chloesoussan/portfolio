
import random
W ="\033[0m" #white
G ="\033[32m" #green
R = "\033[31m" #red
B= "\033[34m" #blue
P = "\033[35m"  #purple        
my_color = [R,B,W,G,R] # création d'une liste qui va contenir toutes les couleurs 


print("saisir une valeur:")
x=int(input())
print("saisir une deuxième valeur: ")
y=int(input())
print("saisir une troisième valeur: ")
z=int(input())

L=[]

A= 3

random.shuffle(my_color)   # random.shuffle permet de mélanger les couleurs dans ma liste my_color                                
for i in range(3): # à chaque tour de boucle on ajoute une couleur qui sera spécifique à la liste [L] et donc chaque couleur sera spécifique à un nombre donné
    L.append(my_color[i])          #on ajoute  une couleur choisie de la liste my_color dans la liste L                   
for j in range(1,A):                   #instruction qui permet  de choisir des couleurs dans ma liste my_color                   
    random.choice(L) #on sélectionne au hasard un élément dans la liste L
B=L[0]                                               
i=1
verification=1 

while i<len(L):      
    if L[i] == B:        # vérifie que la couleur choisie est la même que la première couleur de la liste my_color                              
        verification += 1              # vérifie que les nombres choisis sont de la même couleur                        
        i += 1      
    else:
        i +=1
if verification == 3:# les 3 nombres entrés sont de la même couleur
    print("Ce triplet (", end= '')
    print(L[0],x, end= '')
    print(",", end= '')
    print(L[1],y, end= '')
    print(",", end= '')
    print(L[2],z, end= '')
    print(W, end= '')
    print(") est monochromatique " ,end= '')               
else:
    print("Ce triplet (", end= '')
    print(L[0],x, end= '')
    print(",", end= '')
    print(L[1],y, end= '')
    print(",", end= '')
    print(L[2],z, end= '')
    print(W, end= '')
    print(") n'est pas monochromatique ",end= '' )       

