
import random
W ="\033[0m" #white
G ="\033[32m" #green
R = "\033[31m" #red
B= "\033[34m" #blue
P = "\033[35m"  #purple        
my_color = [R,B,W,G,R] #création d'une liste qui contient toutes les couleurs 

n= int(input("saisir une valeur: "))
for i in range (1, n+1):
    if(i %2 == 0):
        print(R,i ,",",end= '')    #end= '' permet d'avoir les éléments sur une même ligne
    else:
        print(B,i,",",end= '')
