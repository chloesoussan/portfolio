import random

W= "\033[0m"   #white (normal)
R= "\033[31m"  #red
G= "\033[32m"  #green
O= "\033[33m"  #orange
B= "\033[34m"  #blue
P= "\033[35m"  #purple

i= 1                     # compteur de boucle

my_color= [W, R, G, O, B, P]
colors= []

nbCouleurs = int(input("Veuillez entrer le nombre de couleurs souhaité : "))    # on initialise le nombre de couleurs à 2 car on cherche S(2)= N
    

random.shuffle(my_color)


for j in range(0, nbCouleurs ):
    colors.append(my_color[j])

N = 2                                              # représente l'entier maximal N qu'on peut colorier avec nbCouleurs souhaité

while i >0:
    colors2 = []
    
    for k in range(0,N):
        colors2.append(colors[0])
     
    p= 0                                            # représente nbre qui sera retranscrit en base nbCouleurs pour assigner les couleurs à a,b,a+b
    triplet_monochro = 0                            # variable qui déterminera le nombre de triplet monochromatique
    
    nb_coloration= nbCouleurs ** len(colors2)       # représente le nombre de colorations possible pour nbCouleurs donné
    
    while p < nb_coloration:
        verification = 1                            # variable qui vaut 0 s'il y a un triplet monochromatique pour une coloration
        nombre = p
        liste =  []
        
        ''' partie qui traite exo2_5 sur le valeur binaire d'un nombre décimal'''
        while nombre >= 0:
            nb_choisi = nombre
            quotient= nombre / nbCouleurs
            nombre = int(quotient)
            
            if nb_choisi % nbCouleurs == 0:         # condition éxécutée si le reste vaut 0
                liste.append(0)                     # ajout à la fin de la liste un 0
                if nombre == 0:
                    while len(liste) !=N:
                        liste.append(0)
                    nombre = -1                     # permet de sortir de la boucle
                        
            else:                                   # si le reste est différent de 0, on ajoute ce reste à la fin de la liste des restes
                reste = nb_choisi % nbCouleurs 
                liste.append(reste)
                
                if nombre == 0:
                    while len(liste) != N:          # ex: N= 4 et je souhaite mettre 2 en base 2 vaut 10
                        liste.append(0)             # ainsi, comme il faut 4 chiffres on rajoute des 0
                    nombre = -1
                    
        for a in range(1, int(N/2) +1):             # a allant de 1 à 2 pour N= 2 car int(N/2) + 1= 1+1= 2
            for b in range(1,N):                    # b allant de 1 à 2 pour N= 2
                if (a+b) <= N:                                   
                    if a<=b:
                        couleur_a = colors[liste[a-1]]           # désigne pour a = 1: c= liste[0] et d= colors[c] donc on a couleur_a= d
                        couleur_b = colors[liste[b-1]]
                        couleur_somme = colors[liste[(a+b)-1]]
                        
                        print("(",end="")
                        print(couleur_a, a, end="")
                        print(", ", end="")
                        #print('\033[0m', end="")
                        print(couleur_b, b, end="")
                        print(", ", end="")
                        #print('\033[0m', end="")
                        print(couleur_somme, a+b, end="")
                        print('\033[0m', end="")
                        
                        if a == int(N/2) and (a+b)== N:                                   # détermine si c'est le dernier triplet de la liste ou pas
                            print(")")
                        else:
                            print("),", end="")
                        
                    
                        if a!=b and couleur_a == couleur_b == couleur_somme:              # condition qui détermine si a différent de b et que les couleurs a,b,somme sont identiques
                            verification = 0
                            
                        elif a==b and couleur_a == couleur_somme:                         # condition qui détermine si a égal à b et couleur de a est la même que celle de somme 
                            verification = 0
                            
                        
        if verification == 0:                                            # condition qui vérifie si la coloration affichée contient un triplet monochromatique
            triplet_monochro +=1
        if triplet_monochro == nb_coloration:                            # vérifie si la valeur du triplet monochromatique est = au nb_coloration
            i = -1
            p = nb_coloration 
            print("S(",nbCouleurs ,")= ", N-1)
        p+=1
        print(p)
    i+=1
    N+=1
    