'''même idée que l'exo 2_3'''

import random
W= "\033[0m"   #white (normal)
R= "\033[31m"  #red
G= "\033[32m"  #green
O= "\033[33m"  #orange
B= "\033[34m"  #blue
P= "\033[35m"  #purple

my_color= [W, R, P, O, B, G]

print("Veuillez saisir le nombre d'entier que vous souhaitez: ", end= '')
N= int(input())

print("Veuillez saisir le nombre de couleurs que vous souhaitez: ", end= '')
nbCouleurs= int(input())

colors= []                                                  # liste vide de colors 
l= []                                                       # liste stockera l'ensemble des colorations possibles à partir de n couleurs pour N premiers entiers

random.shuffle(my_color)

verification = 0


for i in range(0,nbCouleurs):                               # permet d'avoir les n couleurs souhaitées
    colors.append(my_color[i])
  

for a in range(1, int(N/2)+1):             
    random.shuffle(colors)                                   # shuffle(): mélange les couleurs
    
    couleur_a = colors[random.randrange(0,nbCouleurs)]       # randrange(0,n): choisi un nombre entier aléatoire de 1 à n-1
    couleur_b = colors[random.randrange(0,nbCouleurs)]
    couleur_somme = colors[random.randrange(0,nbCouleurs)]
    
    ''' pour que les couleurs ne soient pas identiques on utilise la méthode shuffle() et random.randrange() qui mélange à plusieurs reprises les couleurs
mais pour en être sur on utilise une condition qui vérifie ce constat'''
    for b in range(N):
        if (a+b)<= N and a>= int(N/2):            # condition qui vérifie si a => nb entré /2 - méthode int() valeur entière
            if b >= a :                           # condition équivalente à a==b ou b==a
                print("(", end= '')
                print(couleur_a, a, end= '')
                print(",", end= '')
                print(couleur_b, b, end= '')
                print(",", end= '')
                print(couleur_somme, a+b, end= '')
                print(")", end= '')
                    
                if couleur_a == couleur_b == couleur_somme:       # condition qui calcule si les couleurs de chaque élément sont égales
                    verification = 1                              
        elif ((a+b <= N) and (a!=0) and (b!=0)) :
            print("(", end= '')
            print(couleur_a, a, end= '')
            print(",", end= '')
            print(couleur_b, b, end= '')
            print(",", end= '')
            print(couleur_somme, a+b, end= '')
            print(")", end= '')
            
                             
            if couleur_a == couleur_b == couleur_somme:           # condition qui calcule si les couleurs de chaque élément sont égales
                verification = 1

if verification == 1:                                # il y a au moins un triplet monochromatique                               
    print("\nFalse")
    
else:                                                # il n'y a aucun triplet monochromatique
   print("\nTrue")
   l.append((couleur_a, couleur_b, couleur_somme))   # instruction qui stocke la liste de colorations possibles
   print(l)                                          
   
                