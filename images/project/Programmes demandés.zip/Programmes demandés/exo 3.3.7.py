print("Veuillez entrer un nombre décimal: ", end= '')
nombre= int(input())
liste= []

nb_voulu = nombre                          # variable qui ne sera pas modifiée par la suite

while nombre <= 0:
    print("Votre nombre doit être positif ! ")
    nombre= int(input("Veuillez saisir un nouveau nombre décimal: "))
   

while nombre != 0:
    nb_choisi = nombre                     # variable sera changée par la suite
    print(nb_choisi)
    quotient = nombre / 2
    print("---")
    print(quotient)
    nombre = int(quotient)
    
    if (nb_choisi % 2) != 0:               # condition exécutée si le reste vaut 1
        reste = "  " + str(nb_choisi % 2)
        liste.append(reste)                # renvoie une chaîne de caractères contenant l'écriture décimale du nombre reste

    else:                                  
        liste.append("0")
print(liste)

resultat= ""                               # variable qui contiendra le nombre binaire du nombre décimal entré

i = len(liste) - 1                         # len(tab)-1 représente le nombre N que possède la liste
while i >= 0:                              # parcours de la liste 
    resultat += liste[i]                   
    i -= 1  
#print(resultat)

print("Le nombre souhaité", nb_voulu, "a pour valeur binaire", resultat)