import random
W ="\033[0m" #white
G ="\033[32m" #green
R = "\033[31m" #red
B= "\033[34m" #blue
P = "\033[35m"  #purple        
my_color = [R,B,W,G,R]
 
print("saisir un nombre voulu: ")
n=int(input())

my_color = [R,B,W,G,R]

L=[]

print("saisir le nombre de couleurs: ")
y=int(input())


random.shuffle(my_color)    #on mélange la liste contenant les couleurs 

for i in range (y):
    L.append(my_color[i])   #on ajoute une couleur choisie au hasard dans le tableau my_color

for j in range (1,n+1):
    a=random.choice(L)   # on sélectionne au hasard un élément de la liste L
    print(a, j,end= ' ')