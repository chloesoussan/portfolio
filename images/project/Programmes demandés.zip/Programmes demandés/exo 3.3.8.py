print("Veuillez entrer un nombre décimal: ", end= '')
nombre= int(input())
liste= []

nb_voulu = nombre                          # variable qui ne sera pas modifiée par la suite

b= int(input("Veuillez saisir une base strictement supérieur à 1: ")) 

while nombre <=0 or b<= 1:
    nombre= int(input("Veuillez saisir un nouveau nombre décimal: "))
    b= int(input("Veuillez saisir une nouvelle base: "))


while nombre != 0 and b > 1:
    nb_choisi = nombre                     # variable sera changée par la suite 
    quotient = nombre / b
    nombre = int(quotient)
    
    if (nb_choisi % b) != 0:               # condition exécutée si le reste vaut 1 
        reste = " " + str(nb_choisi % b)
        #print(reste)
        liste.append(reste)                  # renvoie une chaîne de caractères contenant l'écriture décimale du nombre reste

    else:                                  
        liste.append("0")
print(liste)

resultat= ""                               # variable qui contiendra le nombre binaire du nombre décimal entré

i = len(liste) - 1                           # len(tab)-1 représente le nombre N que possède la liste
while i >= 0:                              # parcours de la liste 
    resultat += liste[i]                   
    i -= 1  
#print(resultat)

print("Le nombre souhaité", nb_voulu, "a pour valeur binaire", resultat, "en base", b)
