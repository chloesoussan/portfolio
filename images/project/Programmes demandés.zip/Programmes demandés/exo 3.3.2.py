import random
W= "\033[0m"   #white (normal)
R= "\033[31m"  #red
G= "\033[32m"  #green
O= "\033[33m"  #orange
B= "\033[34m"  #blue
P= "\033[35m"  #purple

print("Veuillez saisir le nombre d'entier dont vous souhaitez avoir les triplets: ", end= '')
p= int(input())

for a in range(p):
    for b in range(p):
        if (a+b)<= p and a>= int(p/2):                                 # condition qui vérifie si a => nb entré /2 - méthode int() valeur entière
            if b >= a:                                                 # condition équivalente à a==b ou b==a et permet de supprimer les redondances tels que (1,3,4) et (3,1,4)
                print((a,b,a+b), " ", end= '')
        elif ((a+b <= p) and (a!=0) and (b!=0)) :                      # car chaque élément des triplets =! 0
            print((a,b,a+b), " ", end= '')
               
    

