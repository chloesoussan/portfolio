
nbCouleurs = int(input("Veuillez entrer le nombre de couleurs souhaité : "))
    

if nbCouleurs < 6:
    print("Vous devez choisir un nombre de couleurs supérieur à 6 couleurs ! ")
    nbCouleurs = int(input("Veuillez entrer le nombre de couleurs souhaité : "))        


'''ce bloc permet d'estimer la valeur de S(nbCouleurs) lorsque nbCouleurs >= 6 car N est trop important
tout en respevctant la condition suivantes : ((3*nbCouleurs - 1) / 2) <= S(n) <= 3*n! -1'''

if nbCouleurs >= 6:                                 # car on peut borner la valeur de S(n) lorsque n >= 6
    borne1 = int(((3** nbCouleurs )-1)/2)
    n = 1                                           # n! désigne la factorielle d'un nombre entier naturel n notée n
                                                    # ex: 3!= 1*2*3= 6
    for j in range(1,nbCouleurs +1):
        n = n*j
    
    borne2 = 3*n-1                                   # le calcul de n factorielle est déterminé grâce à la boucle pour
    
    
    print("Ton nombre de couleurs est de ", nbCouleurs, "couleurs, supérieur ou égal à 6 couleurs, alors on peut borner la valeur de S(n)")
    print("S(", nbCouleurs,") se trouve dans l'intervalle [", borne1,",", borne2,"].")
