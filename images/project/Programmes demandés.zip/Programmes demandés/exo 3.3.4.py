import random
W= "\033[0m"   #white (normal)
R= "\033[31m"  #red
G= "\033[32m"  #green
O= "\033[33m"  #orange
B= "\033[34m"  #blue
#P= "\033[35m"  #purple

my_color= [W, R, O, G, B]

print("Veuillez saisir le nombre d'entier que vous souhaitez: ", end= '')
N= int(input())

print("Veuillez saisir le nombre de couleurs que vous souhaitez: ", end= '')
nbCouleurs= int(input())

colors= []                                                  # liste vide de colors 

random.shuffle(my_color)

for i in range(nbCouleurs):
    colors.append(my_color[i])
            
liste_couleur2 = [""]                                           #liste qui contiendra les couleurs apparues 

for k in range(1,N+1):
    c= random.choice(colors)
    i = 0
    while i < len(liste_couleur2):
        if c != liste_couleur2[i]:                #si la couleur choisie au hasard est différente de la couleur au rang i de la liste liste_couleur2
            if i == len(liste_couleur2)-1:        # condition qui vérifie si on a parcouru toute la liste 
                if liste_couleur2[0] == "":
                    liste_couleur2[0] = c
                    i+=1
                else:
                    liste_couleur2.append(c)      # mettre la couleur choisie à la fin de la liste
                    i+=1
            else:
                i+=1
        else:
            i = len(liste_couleur2)                # pour sortir de la boucle car couleur choisie est déjà comprise dans la liste
    print(c, k, end= '')
    print('\033[39m', end= '')
# print(tab_couleur2)


if nbCouleurs == len(liste_couleur2):
    print("\nLe coloriage des nombres est valide.")    # méthode \n permet d'aller à la ligne
else:
    print("\nLe coloriage des nombres n'est pas valide.")
    